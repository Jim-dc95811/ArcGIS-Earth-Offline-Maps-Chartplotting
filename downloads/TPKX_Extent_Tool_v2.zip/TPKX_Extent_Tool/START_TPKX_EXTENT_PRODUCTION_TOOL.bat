@echo off
setlocal
cd /d "%~dp0System Files"

where python.exe >nul 2>&1
if errorlevel 1 (
    echo.
    echo TPKX Extent Production Tool requires Python on this computer.
    echo.
    pause
    exit /b 1
)

python.exe "TPKX_EXTENT_PRODUCTION_TOOL_START.py"
