#!/usr/bin/env python3
"""
TPKX EXTENT PRODUCTION TOOL

One-page combination of four proven project utilities:
  1. Two diagonal GPS points from Windows Clipboard History -> EPSG:3857 extent
  2. Same-size neighbor extent calculator
  3. 24-box production split (6 columns x 4 rows)
  4. 10-box Z20 split (2 columns x 5 rows)

The split math preserves the Decimal/shared-boundary behavior of the supplied
GOLD 24-box and 10-box scripts. The clipboard and neighbor behavior preserves
the corresponding Network Earth utilities supplied with this task.
"""

from __future__ import annotations

import base64
import json
import math
import os
import re
import subprocess
import tkinter as tk
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP, getcontext
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

getcontext().prec = 40

APP_NAME = "TPKX Extent Production Tool"
EPSG_TAG = "[EPSG:3857]"
DECIMAL_PLACES = Decimal("0.0001")
WEB_MERCATOR_LIMIT = Decimal("20037508.342789244")

EXTENT_PATTERN = re.compile(
    r"""
    ^\s*
    (?:(?P<label>[^\s,]+)\s+)?
    (?P<xmin>-?\d+(?:\.\d+)?)\s*,\s*
    (?P<xmax>-?\d+(?:\.\d+)?)\s*,\s*
    (?P<ymin>-?\d+(?:\.\d+)?)\s*,\s*
    (?P<ymax>-?\d+(?:\.\d+)?)\s*
    (?:\[EPSG:\s*3857\])?
    \s*$
    """,
    re.IGNORECASE | re.VERBOSE,
)

GOOGLE_POINT_RE = re.compile(
    r"^\s*([+-]?(?:\d{1,2}(?:\.\d+)?|90(?:\.0+)?))\s*,\s*"
    r"([+-]?(?:\d{1,3}(?:\.\d+)?|180(?:\.0+)?))\s*$"
)

POWERSHELL_CLIPBOARD_HISTORY = r'''
$ErrorActionPreference = "Stop"
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    function Await-WinRT {
        param(
            [Parameter(Mandatory=$true)] $Operation,
            [Parameter(Mandatory=$true)] [Type] $ResultType
        )
        $method = [System.WindowsRuntimeSystemExtensions].GetMethods() |
            Where-Object {
                if ($_.Name -ne "AsTask" -or -not $_.IsGenericMethodDefinition) { return $false }
                if ($_.GetGenericArguments().Count -ne 1 -or $_.GetParameters().Count -ne 1) { return $false }
                $returnType = $_.ReturnType
                return ($returnType.IsGenericType -and $returnType.GetGenericTypeDefinition().FullName -eq 'System.Threading.Tasks.Task`1')
            } | Select-Object -First 1
        if ($null -eq $method) { throw "Could not locate Windows Runtime AsTask adapter." }
        $task = $method.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
        $task.Wait()
        return $task.Result
    }
    $historyOperation = [Windows.ApplicationModel.DataTransfer.Clipboard,Windows.ApplicationModel.DataTransfer,ContentType=WindowsRuntime]::GetHistoryItemsAsync()
    $result = Await-WinRT $historyOperation ([Windows.ApplicationModel.DataTransfer.ClipboardHistoryItemsResult,Windows.ApplicationModel.DataTransfer,ContentType=WindowsRuntime])
    $status = [int]$result.Status
    if ($status -ne 0) {
        @{ status = $status; items = @() } | ConvertTo-Json -Compress -Depth 4
        exit 0
    }
    $rows = @()
    foreach ($item in ($result.Items | Sort-Object Timestamp -Descending)) {
        $content = $item.Content
        if ($content.Contains([Windows.ApplicationModel.DataTransfer.StandardDataFormats,Windows.ApplicationModel.DataTransfer,ContentType=WindowsRuntime]::Text)) {
            $textOperation = $content.GetTextAsync()
            $text = Await-WinRT $textOperation ([string])
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                $textBytes = [System.Text.Encoding]::UTF8.GetBytes([string]$text)
                $rows += [pscustomobject]@{
                    timestamp = $item.Timestamp.ToString("o")
                    text_b64 = [System.Convert]::ToBase64String($textBytes)
                }
            }
        }
    }
    @{ status = 0; items = $rows } | ConvertTo-Json -Compress -Depth 4
}
catch {
    @{ status = -1; error = $_.Exception.Message; items = @() } | ConvertTo-Json -Compress -Depth 4
    exit 0
}
'''


def q(value: Decimal) -> Decimal:
    return value.quantize(DECIMAL_PLACES, rounding=ROUND_HALF_UP)


def fmt(value: Decimal) -> str:
    return f"{q(value):.4f}"


def safe_filename(label: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", label).strip("._")
    return cleaned or "BOX"


def parse_labeled_extent(text: str) -> tuple[str, Decimal, Decimal, Decimal, Decimal]:
    match = EXTENT_PATTERN.match((text or "").strip())
    if not match:
        raise ValueError(
            "Expected: optional-label xmin,xmax,ymin,ymax [EPSG:3857]"
        )

    label = match.group("label") or "BOX"
    xmin = Decimal(match.group("xmin"))
    xmax = Decimal(match.group("xmax"))
    ymin = Decimal(match.group("ymin"))
    ymax = Decimal(match.group("ymax"))

    if xmin >= xmax:
        raise ValueError("Xmin must be less than Xmax.")
    if ymin >= ymax:
        raise ValueError("Ymin must be less than Ymax.")

    for name, value in (("Xmin", xmin), ("Xmax", xmax), ("Ymin", ymin), ("Ymax", ymax)):
        if abs(value) > WEB_MERCATOR_LIMIT:
            raise ValueError(f"{name} is outside the normal EPSG:3857 Web Mercator range.")

    return label, q(xmin), q(xmax), q(ymin), q(ymax)


def canonical_extent(text: str) -> str:
    _label, xmin, xmax, ymin, ymax = parse_labeled_extent(text)
    return f"{fmt(xmin)},{fmt(xmax)},{fmt(ymin)},{fmt(ymax)} {EPSG_TAG}"


def make_boundaries(minimum: Decimal, maximum: Decimal, divisions: int) -> list[Decimal]:
    span = maximum - minimum
    step = span / Decimal(divisions)
    boundaries = [q(minimum)]
    for index in range(1, divisions):
        boundaries.append(q(minimum + step * Decimal(index)))
    boundaries.append(q(maximum))
    return boundaries


def generate_split(text: str, columns: int, rows: int) -> tuple[str, str, list[str]]:
    label, xmin, xmax, ymin, ymax = parse_labeled_extent(text)
    x_edges = make_boundaries(xmin, xmax, columns)
    y_edges = make_boundaries(ymin, ymax, rows)

    lines: list[str] = []
    number = 1
    for row_from_north in range(rows):
        north_index = rows - row_from_north
        tile_ymax = y_edges[north_index]
        tile_ymin = y_edges[north_index - 1]
        for col in range(columns):
            tile_xmin = x_edges[col]
            tile_xmax = x_edges[col + 1]
            tile_id = f"{label}-{number:02d}"
            lines.append(
                f"{tile_id} {fmt(tile_xmin)},{fmt(tile_xmax)},"
                f"{fmt(tile_ymin)},{fmt(tile_ymax)} {EPSG_TAG}"
            )
            number += 1

    parent = f"{fmt(xmin)},{fmt(xmax)},{fmt(ymin)},{fmt(ymax)} {EPSG_TAG}"
    return label, parent, lines


@dataclass(frozen=True)
class Extent:
    xmin: Decimal
    xmax: Decimal
    ymin: Decimal
    ymax: Decimal

    @property
    def width(self) -> Decimal:
        return self.xmax - self.xmin

    @property
    def height(self) -> Decimal:
        return self.ymax - self.ymin

    @property
    def qgis_text(self) -> str:
        return f"{fmt(self.xmin)},{fmt(self.xmax)},{fmt(self.ymin)},{fmt(self.ymax)} {EPSG_TAG}"


def neighbor_extent(home_text: str, direction: str) -> str:
    _label, xmin, xmax, ymin, ymax = parse_labeled_extent(home_text)
    center = Extent(xmin, xmax, ymin, ymax)
    width = center.width
    height = center.height

    neighbors = {
        "NW": Extent(center.xmin - width, center.xmax - width, center.ymin + height, center.ymax + height),
        "N":  Extent(center.xmin,         center.xmax,         center.ymin + height, center.ymax + height),
        "NE": Extent(center.xmin + width, center.xmax + width, center.ymin + height, center.ymax + height),
        "E":  Extent(center.xmin + width, center.xmax + width, center.ymin,          center.ymax),
        "SE": Extent(center.xmin + width, center.xmax + width, center.ymin - height, center.ymax - height),
        "S":  Extent(center.xmin,         center.xmax,         center.ymin - height, center.ymax - height),
        "SW": Extent(center.xmin - width, center.xmax - width, center.ymin - height, center.ymax - height),
        "W":  Extent(center.xmin - width, center.xmax - width, center.ymin,          center.ymax),
    }

    result = neighbors[direction.upper()]
    for name, value in (("Xmin", result.xmin), ("Xmax", result.xmax), ("Ymin", result.ymin), ("Ymax", result.ymax)):
        if abs(value) > WEB_MERCATOR_LIMIT:
            raise ValueError(f"Neighbor {direction.upper()} would extend beyond the EPSG:3857 world limits.")
    return result.qgis_text


def parse_google_maps_point(text: str):
    match = GOOGLE_POINT_RE.match((text or "").strip())
    if not match:
        return None
    lat = float(match.group(1))
    lon = float(match.group(2))
    if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
        return None
    return lat, lon


def latlon_to_web_mercator(lat: float, lon: float):
    lat = max(-85.0511287798066, min(85.0511287798066, lat))
    radius = 6378137.0
    x = radius * math.radians(lon)
    y = radius * math.log(math.tan((math.pi / 4.0) + (math.radians(lat) / 2.0)))
    return x, y


def extent_from_google_points(point_a, point_b) -> str:
    x1, y1 = latlon_to_web_mercator(*point_a)
    x2, y2 = latlon_to_web_mercator(*point_b)
    xmin, xmax = sorted((x1, x2))
    ymin, ymax = sorted((y1, y2))
    return f"{xmin:.4f},{xmax:.4f},{ymin:.4f},{ymax:.4f} {EPSG_TAG}"


def _decode_powershell_output(data: bytes) -> str:
    if not data:
        return ""
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16").strip()
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig").strip()

    sample = data[:256]
    even_nuls = sample[0::2].count(0)
    odd_nuls = sample[1::2].count(0)
    threshold = max(3, len(sample) // 10)
    if odd_nuls >= threshold and odd_nuls > even_nuls * 2:
        return data.decode("utf-16-le").strip()
    if even_nuls >= threshold and even_nuls > odd_nuls * 2:
        return data.decode("utf-16-be").strip()
    try:
        return data.decode("utf-8-sig").strip()
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace").strip()


def windows_clipboard_history_texts() -> list[str]:
    if os.name != "nt":
        raise RuntimeError("Windows Clipboard History is only available on Windows.")

    result = subprocess.run(
        [
            "powershell.exe",
            "-NoLogo",
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-Command", POWERSHELL_CLIPBOARD_HISTORY,
        ],
        capture_output=True,
        text=False,
        creationflags=subprocess.CREATE_NO_WINDOW,
        timeout=15,
    )

    raw = _decode_powershell_output(result.stdout)
    if not raw:
        detail = _decode_powershell_output(result.stderr)
        raise RuntimeError(detail or "Windows returned no clipboard-history data.")

    try:
        payload = json.loads(raw.lstrip("\ufeff"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Could not decode Clipboard History ({exc.msg} at character {exc.pos})."
        ) from exc

    status = int(payload.get("status", -1))
    if status == 2:
        raise RuntimeError("Windows Clipboard History is disabled. Press Win+V once and turn Clipboard History on.")
    if status == 1:
        raise RuntimeError("Windows denied access to Clipboard History.")
    if status != 0:
        raise RuntimeError(payload.get("error") or "Clipboard History could not be read.")

    items = payload.get("items") or []
    if isinstance(items, dict):
        items = [items]

    texts: list[str] = []
    for item in items:
        raw_text = base64.b64decode(str(item.get("text_b64", "")), validate=True)
        text = raw_text.decode("utf-8").strip()
        if text:
            texts.append(text)
    return texts


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1420x860")
        self.minsize(1200, 760)

        self.home_var = tk.StringVar()
        self.neighbor_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Ready")
        self.split24_lines: list[str] = []
        self.split10_lines: list[str] = []
        self.split24_label = "BOX"
        self.split10_label = "BOX"
        self.split24_parent = ""
        self.split10_parent = ""

        self._build_ui()

    def _build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.columnconfigure(1, weight=1)
        outer.rowconfigure(2, weight=1)

        ttk.Label(outer, text="TPKX EXTENT PRODUCTION TOOL", font=("Segoe UI", 18, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10)
        )

        home = ttk.LabelFrame(outer, text="HOME / PARENT EXTENT — optional label + xmin,xmax,ymin,ymax [EPSG:3857]", padding=10)
        home.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(0, 12))
        home.columnconfigure(0, weight=1)
        ttk.Entry(home, textvariable=self.home_var, font=("Consolas", 11)).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(home, text="COPY HOME", command=lambda: self._copy(self.home_var.get())).grid(row=0, column=1)

        left = ttk.Frame(outer)
        right = ttk.Frame(outer)
        left.grid(row=2, column=0, sticky="nsew", padx=(0, 6))
        right.grid(row=2, column=1, sticky="nsew", padx=(6, 0))
        left.rowconfigure(1, weight=1)
        right.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)
        right.columnconfigure(0, weight=1)

        self._build_clipboard_panel(left)
        self._build_split_panel(left, row=1, title="24-BOX PRODUCTION SPLIT — 6 x 4", count=24)
        self._build_neighbor_panel(right)
        self._build_split_panel(right, row=1, title="10-BOX Z20 SPLIT — 2 x 5", count=10)

        ttk.Label(outer, textvariable=self.status_var, anchor="w").grid(
            row=3, column=0, columnspan=2, sticky="ew", pady=(10, 0)
        )

    def _build_clipboard_panel(self, parent):
        box = ttk.LabelFrame(parent, text="2 DIAGONAL GPS POINTS → EPSG:3857 EXTENT", padding=10)
        box.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        box.columnconfigure(0, weight=1)
        ttk.Label(
            box,
            text="Copy two opposite-corner lat,lon coordinates into Windows Clipboard History, then load them.",
            wraplength=620,
        ).grid(row=0, column=0, sticky="w", pady=(0, 8))
        ttk.Button(box, text="LOAD LAST 2 GPS POINTS FROM CLIPBOARD HISTORY", command=self.load_clipboard_points).grid(
            row=1, column=0, sticky="ew"
        )

    def _build_neighbor_panel(self, parent):
        box = ttk.LabelFrame(parent, text="NEIGHBOR EXTENT — SAME SIZE AS HOME", padding=10)
        box.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        for col in range(3):
            box.columnconfigure(col, weight=1)

        directions = [
            ("NW", 0, 0), ("N", 0, 1), ("NE", 0, 2),
            ("W", 1, 0), ("HOME", 1, 1), ("E", 1, 2),
            ("SW", 2, 0), ("S", 2, 1), ("SE", 2, 2),
        ]
        for text, row, col in directions:
            if text == "HOME":
                ttk.Label(box, text="HOME", anchor="center", font=("Segoe UI", 10, "bold")).grid(row=row, column=col, sticky="ew", padx=3, pady=3)
            else:
                ttk.Button(box, text=text, command=lambda d=text: self.calculate_neighbor(d)).grid(row=row, column=col, sticky="ew", padx=3, pady=3)

        ttk.Entry(box, textvariable=self.neighbor_var, font=("Consolas", 10)).grid(
            row=3, column=0, columnspan=2, sticky="ew", padx=(0, 6), pady=(8, 0)
        )
        ttk.Button(box, text="COPY", command=lambda: self._copy(self.neighbor_var.get())).grid(row=3, column=2, sticky="ew", pady=(8, 0))

    def _build_split_panel(self, parent, row: int, title: str, count: int):
        box = ttk.LabelFrame(parent, text=title, padding=10)
        box.grid(row=row, column=0, sticky="nsew")
        box.columnconfigure(0, weight=1)
        box.rowconfigure(1, weight=1)

        controls = ttk.Frame(box)
        controls.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        controls.columnconfigure(0, weight=1)

        if count == 24:
            command = self.generate_24
            copy_command = lambda: self._copy("\n".join(self.split24_lines))
            save_command = self.save_24
            button_text = "GENERATE 24"
        else:
            command = self.generate_10
            copy_command = lambda: self._copy("\n".join(self.split10_lines))
            save_command = self.save_10
            button_text = "GENERATE 10"

        ttk.Button(controls, text=button_text, command=command).grid(row=0, column=0, sticky="w")
        ttk.Button(controls, text="COPY ALL", command=copy_command).grid(row=0, column=1, padx=6)
        ttk.Button(controls, text="SAVE TXT", command=save_command).grid(row=0, column=2)

        text = tk.Text(box, wrap="none", height=15, font=("Consolas", 9))
        text.grid(row=1, column=0, sticky="nsew")
        yscroll = ttk.Scrollbar(box, orient="vertical", command=text.yview)
        yscroll.grid(row=1, column=1, sticky="ns")
        text.configure(yscrollcommand=yscroll.set)

        if count == 24:
            self.text24 = text
        else:
            self.text10 = text

    def _copy(self, text: str):
        text = (text or "").strip()
        if not text:
            return
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status_var.set("Copied to clipboard.")

    def load_clipboard_points(self):
        try:
            history = windows_clipboard_history_texts()
            points = []
            seen = set()
            for text in history:
                point = parse_google_maps_point(text)
                if point is None:
                    continue
                key = (round(point[0], 10), round(point[1], 10))
                if key in seen:
                    continue
                seen.add(key)
                points.append(point)
                if len(points) == 2:
                    break

            if len(points) < 2:
                raise RuntimeError(
                    "Could not find two recent lat,lon coordinate entries in Windows Clipboard History."
                )

            extent = canonical_extent(extent_from_google_points(points[0], points[1]))
            self.home_var.set(extent)
            self.neighbor_var.set("")
            self.status_var.set("Loaded the last two unique GPS points and created the HOME extent.")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def calculate_neighbor(self, direction: str):
        try:
            result = neighbor_extent(self.home_var.get(), direction)
            self.neighbor_var.set(result)
            self.status_var.set(f"Calculated {direction} neighbor.")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def _set_text(self, widget: tk.Text, lines: list[str]):
        widget.delete("1.0", "end")
        widget.insert("1.0", "\n".join(lines))

    def generate_24(self):
        try:
            label, parent, lines = generate_split(self.home_var.get(), 6, 4)
            self.split24_label, self.split24_parent, self.split24_lines = label, parent, lines
            self._set_text(self.text24, lines)
            self.status_var.set("Generated 24 neighbor-perfect extents.")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def generate_10(self):
        try:
            label, parent, lines = generate_split(self.home_var.get(), 2, 5)
            self.split10_label, self.split10_parent, self.split10_lines = label, parent, lines
            self._set_text(self.text10, lines)
            self.status_var.set("Generated 10 neighbor-perfect Z20 extents.")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def save_24(self):
        if not self.split24_lines:
            self.generate_24()
            if not self.split24_lines:
                return
        path = filedialog.asksaveasfilename(
            title="Save 24-box extents",
            defaultextension=".txt",
            initialfile=f"{safe_filename(self.split24_label)}_24_INTERNAL_TILE_EXTENTS_GOLD.txt",
            filetypes=[("Text files", "*.txt")],
        )
        if not path:
            return
        header = [
            f"# Parent box: {self.split24_label}",
            "# Layout: 6 columns west-to-east x 4 rows north-to-south",
            "# Numbering: NW first, east across each row, then south",
            f"# Parent extent: {self.split24_parent}",
            "",
        ]
        Path(path).write_text("\n".join(header + self.split24_lines) + "\n", encoding="utf-8")
        self.status_var.set(f"Saved: {path}")

    def save_10(self):
        if not self.split10_lines:
            self.generate_10()
            if not self.split10_lines:
                return
        path = filedialog.asksaveasfilename(
            title="Save 10-box Z20 extents",
            defaultextension=".txt",
            initialfile=f"{safe_filename(self.split10_label)}_10_Z20_EXTENTS.txt",
            filetypes=[("Text files", "*.txt")],
        )
        if not path:
            return
        header = [
            "# Z20 10-BOX EXTENTS",
            "# Source: TPKX Extent Production Tool",
            f"# Parent box: {self.split10_label}",
            "# Layout: 2 columns west-to-east x 5 rows north-to-south",
            "# Numbering: NW first, east across each row, then south",
            "# Shared boundaries: adjacent boxes use identical edge values",
            f"# Parent extent: {self.split10_parent}",
            "",
        ]
        Path(path).write_text("\n".join(header + self.split10_lines) + "\n", encoding="utf-8")
        self.status_var.set(f"Saved: {path}")


if __name__ == "__main__":
    App().mainloop()
