#!/usr/bin/env python3
from __future__ import annotations

import os
import subprocess
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
GUI = HERE / "TPKX_EXTENT_PRODUCTION_TOOL.pyw"


def fail(text: str) -> int:
    print()
    print("TPKX EXTENT PRODUCTION TOOL STARTUP ERROR")
    print()
    print(text)
    print()
    input("Press Enter to close...")
    return 1


def main() -> int:
    try:
        if not GUI.is_file():
            return fail(f"Required program file is missing:\n{GUI}")
        source = GUI.read_text(encoding="utf-8")
        compile(source, str(GUI), "exec")
    except Exception:
        return fail(traceback.format_exc())

    exe = Path(sys.executable)
    pythonw = exe.with_name("pythonw.exe") if os.name == "nt" else exe
    if os.name == "nt" and not pythonw.exists():
        return fail(f"Python GUI launcher was not found:\n{pythonw}")

    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    subprocess.Popen(
        [str(pythonw), str(GUI)],
        cwd=str(HERE),
        creationflags=flags,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
