@echo off
setlocal
cd /d "%~dp0"
title ArcGIS Earth PRAVE / ME Tracker

where py >nul 2>nul
if %errorlevel%==0 (
    py "PRAVE_ME_Tracker.py"
) else (
    python "PRAVE_ME_Tracker.py"
)

set EXITCODE=%errorlevel%
echo.
echo PRAVE / ME Tracker exited with code %EXITCODE%.
pause
exit /b %EXITCODE%
