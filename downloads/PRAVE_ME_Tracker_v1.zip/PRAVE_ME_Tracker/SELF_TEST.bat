@echo off
setlocal
cd /d "%~dp0"
title PRAVE / ME Tracker - Self Test

where py >nul 2>nul
if %errorlevel%==0 (
    py "PRAVE_ME_Tracker.py" --self-test
) else (
    python "PRAVE_ME_Tracker.py" --self-test
)

echo.
pause
endlocal
