@echo off
setlocal
cd /d "%~dp0"
title PRAVE RMC Field Decoder Tester - Version 1.0 Gold

echo ============================================================
echo   PRAVE / RMC Field Decoder Tester - Version 1.0 Gold
echo ============================================================
echo.
echo COM port and baud rate are configured at the top of the
echo Python file. Press Ctrl+C to stop the live test stream.
echo.

python "PRAVE_RMC_Field_Decoder_Tester_v1_0_Gold.py"

echo.
echo ============================================================
echo Tester exited.
echo ============================================================
pause
endlocal
