ARCGIS TPKX FACTORY GUI v0.2.1 WINDOW FIX TEST
22 AUG 2026

THIS VERSION CHANGES WINDOW BEHAVIOR ONLY.
THE LIVE-PROVEN SINGLE/BATCH EXPORT ENGINE IS UNCHANGED.

FIX 1 - MAIN FACTORY IS NO LONGER MODAL
----------------------------------------
v0.2.0 opened the first Factory with ShowDialog().
That blocked interaction with the separate Batch Factory and caused
Windows/ArcGIS to beep until the first Factory was closed.

v0.2.1 opens the main Factory as an independent modeless window.

Expected behavior:
  Open Factory
  Open Batch Factory
  Both windows are usable
  Close the first Factory if desired
  Batch Factory stays open and keeps running

FIX 2 - BATCH WINDOW FITS WINDOWS DISPLAY SCALING
--------------------------------------------------
The v0.2.0 Batch window was 820 WPF units tall. On a scaled Windows display
that could exceed the physical work area and push the title bar off-screen.

v0.2.1 starts smaller:
  Height 640
  Width 950
  Minimum height 560
  Minimum width 820

The normal Windows title bar remains visible so the Batch window can be
moved, resized, minimized, maximized, or restored normally.

IMPORTANT
---------
Do not install this revision while an active batch is running.
Let the current batch finish first, then install v0.2.1 and restart ArcGIS Pro.
