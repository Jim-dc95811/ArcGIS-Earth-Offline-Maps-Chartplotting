@echo off
setlocal
set "RUNNER=%~dp0Factory\BUILD_QUIET.vbs"
if not exist "%RUNNER%" (
    echo Factory builder files are missing.
    pause
    exit /b 1
)
start "" wscript.exe "%RUNNER%"
exit /b 0
